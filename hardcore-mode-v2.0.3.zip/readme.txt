# Hardcore Mode
# Created: 20/09/2023 [dd/mm/yyyy]
# Author: FoxyNoTail
# Version: 2.0.3
# Made for Minecraft Bedrock Edition 1.20.30
# For more info visit www.foxynotail.com 

WHAT'S NEW IN v2.0.3
------
UPDATE for 1.20
==============
Now uses vanilla spectator mode instead of adventure mode with effects

Just like JAVA Edition's Hardcore Mode...

When you die, you will enter spectator mode which means you will not be able to continue in survival mode.


README
------
TO RUN
======
When you die, you will enter spectator mode which means you will not be able to continue in survival mode.


HELP & SUPPORT
------
For help and questions about Foxy's packs, please join the discord via the link below


LINKS
------
Discord: discord.gg/BqGKecr
YouTube: youtube.com/foxynotail
Twitch: twitch.tv/foxynotail
Twitter: twitter.com/FoxyNoTail
Website: www.foxynotail.com
