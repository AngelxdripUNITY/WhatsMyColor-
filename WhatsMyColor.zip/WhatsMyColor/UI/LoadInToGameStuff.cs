﻿using WhatsMyColor.Backend;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using UnityEngine.UI;

namespace WhatsMyColor.UI
{
    public class LoadInToGameStuff : MonoBehaviourPunCallbacks
    {
        private List<VRRig> vrrigs = new List<VRRig>();

        private void Start()
        {
            if (PhotonNetwork.InRoom)
            {
                RefreshVRRigs();
            }
        }

        private void RefreshVRRigs()
        {
            vrrigs.Clear();
            GameObject[] potentialVRRigs = GameObject.FindObjectsOfType<GameObject>();

            foreach (GameObject obj in potentialVRRigs)
            {
                if (obj.name == "Gorilla Player Networked(Clone)")
                {
                    VRRig rig = obj.GetComponent<VRRig>();
                    if (rig != null)
                    {
                        vrrigs.Add(rig);
                        UpdatePlayerText(rig);
                    }
                }
            }
        }

        private void UpdatePlayerText(VRRig rig)
        {
            Text txt = rig.playerText;
            Color playerColor = rig.playerColor;
            int red = Mathf.RoundToInt(playerColor.r * 9);
            int green = Mathf.RoundToInt(playerColor.g * 9);
            int blue = Mathf.RoundToInt(playerColor.b * 9);
            txt.text += "\n(" + red + ", " + green + ", " + blue + ")";
        }

        public override void OnPlayerEnteredRoom(Photon.Realtime.Player newPlayer)
        {
            base.OnPlayerEnteredRoom(newPlayer);
            RefreshVRRigs();
        }

        public override void OnPlayerLeftRoom(Photon.Realtime.Player otherPlayer)
        {
            base.OnPlayerLeftRoom(otherPlayer);
            RefreshVRRigs();
        }

        private void Update()
        {
            if (PhotonNetwork.InRoom && PhotonNetwork.IsConnected)
            {
                foreach (VRRig rig in vrrigs)
                {
                    if (rig != null)
                    {
                        UpdatePlayerText(rig);
                    }
                }
            }
        }
    }
}
