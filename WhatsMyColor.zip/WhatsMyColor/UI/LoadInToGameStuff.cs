﻿using WhatsMyColor.Backend;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using UnityEngine.UI;
using GTAG_NotificationLib;

namespace WhatsMyColor.UI
{
    public class LoadInToGameStuff : MonoBehaviourPunCallbacks
    {
        public bool isupdated;
        private List<VRRig> vrrigs = new List<VRRig>();
        private bool hascomped;
        private void Start()
        {
            if (!hascomped)
            {
                NotifiLib.SendNotification("<color=white>WHATS MY </color><color=red>CO</color><color=green>LO</color><color=blue>R</color><color=white> HAS SUCCESSFULLY LOADED</color>");
                hascomped = true;
            }
            if (PhotonNetwork.InRoom)
            {
                RefreshVRRigs();
            }
        }

        private void RefreshVRRigs()
        {
            vrrigs.Clear();
            GameObject[] potentialVRRigs = GameObject.FindObjectsOfType<GameObject>();

            foreach (GameObject obj in potentialVRRigs)
            {
                if (obj.name == "Gorilla Player Networked(Clone)")
                {
                    VRRig rig = obj.GetComponent<VRRig>();
                    if (rig != null)
                    {
                        vrrigs.Add(rig);
                        UpdatePlayerText(rig);
                    }
                }
            }
            foreach (VRRig rig in vrrigs)
            {
                if (rig != null)
                {
                    UpdatePlayerText(rig);
                }
            }
        }

        private void UpdatePlayerText(VRRig rig)
        {
            Text txt = rig.playerText;
            Color playerColor = rig.playerColor;
            txt.color = playerColor;
            int red = Mathf.RoundToInt(playerColor.r * 9);
            int green = Mathf.RoundToInt(playerColor.g * 9);
            int blue = Mathf.RoundToInt(playerColor.b * 9);
            txt.text += "\n(" + red + ", " + green + ", " + blue + ")";
            isupdated = true;
        }
        public override void OnPlayerEnteredRoom(Photon.Realtime.Player newPlayer)
        {
            base.OnPlayerEnteredRoom(newPlayer);
            RefreshVRRigs();
        }

        public override void OnPlayerLeftRoom(Photon.Realtime.Player otherPlayer)
        {
            base.OnPlayerLeftRoom(otherPlayer);
            RefreshVRRigs();
        }

        private void Update()
        {

            if (PhotonNetwork.InRoom)
            {

                if (!isupdated)
                {
                    RefreshVRRigs();
                }
                foreach (VRRig rig in vrrigs)
                {
                    if (rig != null)
                    {
                        UpdatePlayerText(rig);
                    }
                }
            }
            else
            {
                isupdated = false;
            }
        }
        
    }
}
