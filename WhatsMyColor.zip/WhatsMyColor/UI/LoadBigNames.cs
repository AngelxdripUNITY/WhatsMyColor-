﻿using GTAG_NotificationLib;
using Photon.Pun;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace MalachiTemp.UI
{
    public class LoadBigNames : MonoBehaviourPunCallbacks
    {
        public bool isupdated;
        private List<VRRig> vrrigs = new List<VRRig>();
        private Dictionary<VRRig, GameObject> rigTextObjects = new Dictionary<VRRig, GameObject>();
        private Dictionary<VRRig, Color> rigColors = new Dictionary<VRRig, Color>();  // Track colors
        private bool hascomped;
        public float x = 35;
        public Font fone;

        private void Start()
        {
            if (!hascomped)
            {
                hascomped = true;
            }
            if (PhotonNetwork.InRoom)
            {
                RefreshVRRigs();
            }
            fone = GameObject.Find("motdtext").GetComponent<Text>().font;
        }

        private void RefreshVRRigs()
        {
            ClearVRRigs();  // Ensure old data is cleared before refreshing

            GameObject[] potentialVRRigs = GameObject.FindObjectsOfType<GameObject>();

            foreach (GameObject obj in potentialVRRigs)
            {
                if (obj.name == "Gorilla Player Networked(Clone)")
                {
                    VRRig rig = obj.GetComponent<VRRig>();
                    if (rig != null)
                    {
                        vrrigs.Add(rig);
                        rigColors[rig] = rig.playerColor;  // Store the initial color
                        UpdatePlayerText(rig);
                    }
                }
            }
        }

        private void ClearVRRigs()
        {
            // Clear the existing lists and destroy associated Text objects
            foreach (var textObj in rigTextObjects.Values)
            {
                Destroy(textObj);
            }
            rigTextObjects.Clear();
            vrrigs.Clear();
            rigColors.Clear();  // Clear the color tracking dictionary
            isupdated = false; // Reset the update flag
        }

        private void UpdatePlayerText(VRRig rig)
        {
            // Define the Y offset
            if (rigTextObjects.TryGetValue(rig, out GameObject existingText))
            {
                // Update the existing Text object
                Text existingTextComponent = existingText.GetComponent<Text>();
                if (existingTextComponent != null)
                {
                    existingTextComponent.color = rig.playerColor;
                    existingTextComponent.font = rig.playerText.font;
                    existingTextComponent.text = rig.playerNameVisible;
                    existingTextComponent.alignment = TextAnchor.MiddleCenter;

                    // Update the position, rotation, and scale
                    existingText.transform.parent = rig.playerText.transform.parent;
                    existingText.transform.rotation = rig.playerText.transform.rotation;
                    existingText.transform.localRotation = rig.playerText.transform.localRotation;
                    existingText.transform.position = new Vector3(x, 120, 0);
                    existingText.transform.localPosition = new Vector3(x, 120, 0);
                    existingText.transform.localScale = new Vector3(2, 2, 2);
                }
            }
            else
            {
                // Create a new Text object for this rig
                GameObject txt2 = new GameObject("Text(Clone)");
                Text txt2text = txt2.AddComponent<Text>();
                txt2text.color = rig.playerColor;
                txt2text.font = rig.playerText.font;
                txt2text.text = rig.playerNameVisible;
                txt2text.alignment = TextAnchor.MiddleCenter;

                // Set the position, rotation, and scale
                txt2.transform.parent = rig.playerText.transform.parent;
                txt2.transform.rotation = rig.playerText.transform.rotation;
                txt2.transform.localRotation = rig.playerText.transform.localRotation;
                txt2.transform.position = new Vector3(x, 120, 0);
                txt2.transform.localPosition = new Vector3(x, 120, 0);
                txt2.transform.localScale = new Vector3(2, 2, 2);

                // Store the reference
                rigTextObjects[rig] = txt2;
            }

            isupdated = true;
        }

        private void UpdateAllPlayerTexts()
        {
            foreach (VRRig rig in vrrigs)
            {
                UpdatePlayerText(rig);
            }
        }

        private void CheckForColorChange()
        {
            foreach (VRRig rig in vrrigs)
            {
                if (rigColors.TryGetValue(rig, out Color previousColor))
                {
                    if (rig.playerColor != previousColor)
                    {
                        rigColors[rig] = rig.playerColor;
                        UpdateAllPlayerTexts(); 
                        break;
                    }
                }
            }
        }

        public override void OnPlayerEnteredRoom(Photon.Realtime.Player newPlayer)
        {
            base.OnPlayerEnteredRoom(newPlayer);
            ClearVRRigs();
            RefreshVRRigs();
            UpdateAllPlayerTexts();
        }

        public override void OnPlayerLeftRoom(Photon.Realtime.Player otherPlayer)
        {
            base.OnPlayerLeftRoom(otherPlayer);
            ClearVRRigs();
            RefreshVRRigs();
            UpdateAllPlayerTexts();
        }

        public override void OnJoinedRoom()
        {
            base.OnJoinedRoom();
            ClearVRRigs();
            RefreshVRRigs();
            UpdateAllPlayerTexts();
        }

        public override void OnLeftRoom()
        {
            base.OnLeftRoom();
            ClearVRRigs();
        }

        private void Update()
        {
            if (PhotonNetwork.InRoom)
            {
                if (!isupdated)
                {
                    ClearVRRigs();
                    RefreshVRRigs();
                    UpdateAllPlayerTexts();
                }
                CheckForColorChange();  // Check for color changes on every update
            }
            else
            {
                ClearVRRigs();
            }
        }
    }
}
