﻿using GTAG_NotificationLib;
using Photon.Pun;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace MalachiTemp.UI
{
    public class LoadBigNames : MonoBehaviourPunCallbacks
    {
        public bool isupdated;
        private List<VRRig> vrrigs = new List<VRRig>();
        private Dictionary<VRRig, GameObject> rigTextObjects = new Dictionary<VRRig, GameObject>();
        private Dictionary<VRRig, Color> rigColors = new Dictionary<VRRig, Color>();  // Track colors
        private bool hascomped;
        public GameObject maincam;
        public float x = 32;
        public Font fone;

        private void Start()
        {
            maincam = GameObject.Find("Main Camera"); 
            if (!hascomped)
            {
                hascomped = true;
            }
            if (PhotonNetwork.InRoom)
            {
                RefreshVRRigs();
            }
            fone = GameObject.Find("motdtext").GetComponent<Text>().font;
        }

        private void RefreshVRRigs()
        {
            ClearVRRigs();  

            GameObject[] potentialVRRigs = GameObject.FindObjectsOfType<GameObject>();

            foreach (GameObject obj in potentialVRRigs)
            {
                if (obj.name == "Gorilla Player Networked(Clone)")
                {
                    VRRig rig = obj.GetComponent<VRRig>();
                    if (rig != null)
                    {
                        vrrigs.Add(rig);
                        rigColors[rig] = rig.playerColor;  // Store the initial color
                        UpdatePlayerText(rig);
                    }
                }
            }
        }

        private void ClearVRRigs()
        {
            foreach (var textObj in rigTextObjects.Values)
            {
                Destroy(textObj);
            }
            rigTextObjects.Clear();
            vrrigs.Clear();
            rigColors.Clear();  
        }

        private void UpdatePlayerText(VRRig rig)
        {
            if (rigTextObjects.TryGetValue(rig, out GameObject existingText))
            {
                Text existingTextComponent = existingText.GetComponent<Text>();
                if (existingTextComponent != null)
                {
                    existingTextComponent.color = rig.playerColor;
                    existingTextComponent.font = rig.playerText.font;
                    existingTextComponent.text = rig.playerNameVisible;
                    existingTextComponent.alignment = TextAnchor.MiddleCenter;

                    existingText.transform.parent = rig.playerText.transform.parent;
                    existingText.transform.position = new Vector3(x, 140, 0);
                    existingText.transform.localPosition = new Vector3(x, 140, 0);
                    existingText.transform.localScale = new Vector3(3, 3, 3);
                }
            }
            else
            {
                // Create a new Text object for this rig
                GameObject txt2 = new GameObject("Text(Clone)");
                Text txt2text = txt2.AddComponent<Text>();
                txt2text.color = rig.playerColor;
                txt2text.font = rig.playerText.font;
                txt2text.text = rig.playerNameVisible;
                txt2text.alignment = TextAnchor.MiddleCenter;

                // Set the position, rotation, and scale
                txt2.transform.parent = rig.playerText.transform.parent;
                txt2.transform.position = new Vector3(x, 140, 0);
                txt2.transform.localPosition = new Vector3(x, 140, 0);
                txt2.transform.localScale = new Vector3(3, 3, 3);

                // Store the reference
                rigTextObjects[rig] = txt2;
            }

            isupdated = true;
        }

        private void UpdateAllPlayerTexts()
        {
            foreach (VRRig rig in vrrigs)
            {
                UpdatePlayerText(rig);
            }
        }

        private void CheckForColorChange()
        {
            foreach (VRRig rig in vrrigs)
            {
                if (rigColors.TryGetValue(rig, out Color previousColor))
                {
                    if (rig.playerColor != previousColor)
                    {
                        rigColors[rig] = rig.playerColor;
                        UpdateAllPlayerTexts();
                        break;
                    }
                }
            }
        }

        public override void OnPlayerEnteredRoom(Photon.Realtime.Player newPlayer)
        {
            base.OnPlayerEnteredRoom(newPlayer);
            ClearVRRigs();
            RefreshVRRigs();
            UpdateAllPlayerTexts();
        }

        public override void OnPlayerLeftRoom(Photon.Realtime.Player otherPlayer)
        {
            base.OnPlayerLeftRoom(otherPlayer);
            ClearVRRigs();
            RefreshVRRigs();
            UpdateAllPlayerTexts();
        }

        public override void OnJoinedRoom()
        {
            base.OnJoinedRoom();
            ClearVRRigs();
            RefreshVRRigs();
            UpdateAllPlayerTexts();
        }

        public override void OnLeftRoom()
        {
            base.OnLeftRoom();
            ClearVRRigs();
            isupdated = false;
        }

        private void Update()
        {
            if (PhotonNetwork.InRoom)
            {
                if (!isupdated)
                {
                    ClearVRRigs();
                    RefreshVRRigs();
                    UpdateAllPlayerTexts();
                }
                CheckForColorChange();

                RotateAllTextObjectsTowardsMainCam();  // Rotate all text objects every frame
            }
            else
            {
                ClearVRRigs();
            }
        }

        private void RotateAllTextObjectsTowardsMainCam()
        {
            if (maincam != null)
            {
                foreach (var textObj in rigTextObjects.Values)
                {
                    Vector3 directionToCamera = maincam.transform.position - textObj.transform.position;
                    Quaternion lookRotation = Quaternion.LookRotation(directionToCamera);
                    lookRotation *= Quaternion.Euler(180f, 0f, 180f);

                    textObj.transform.rotation = lookRotation;
                }
            }
        }

    }
}
