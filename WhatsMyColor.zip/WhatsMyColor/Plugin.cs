﻿using BepInEx;
using WhatsMyColor.Backend;
using WhatsMyColor.UI;
using HarmonyLib;
using Loading;
using UnityEngine;
using Object = UnityEngine.Object;

namespace WhatsMyColor
{
    [BepInPlugin(Name, GUID, Version)]
    public class Plugin : BaseUnityPlugin
    {
        public const string Name = "angelplayerdetails";
        public const string GUID = "angel.playerdetails";
        public const string Version = "1.0";

        private bool patchedHarmony = false;
        [System.Serializable]
        public class LoginData
        {
            public string license;

        }
        void Awake()
        {
            if (!patchedHarmony && Loader.loaded == false)
            {
                Harmony harmony = new Harmony(GUID);
                harmony.PatchAll();
                patchedHarmony = true;
                Loader.loaded = true;

            }
        }
    }
    [HarmonyPatch(typeof(GorillaLocomotion.Player), "FixedUpdate")]
    internal class UpdatePatch
    {
        private static bool alreadyInit;
        public static GameObject Gameobject;

        static void Postfix()
        {
           
            if (!alreadyInit)
            {
                alreadyInit = true;
                Gameobject = new GameObject();
                Gameobject.AddComponent<Plugin>();
                Gameobject.AddComponent<LoadInToGameStuff>();
                Gameobject.AddComponent<GTAG_NotificationLib.NotifiLib>();
            }
        }
    }
}
