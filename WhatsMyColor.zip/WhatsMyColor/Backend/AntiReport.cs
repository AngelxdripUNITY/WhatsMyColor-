﻿using GTAG_NotificationLib;
using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace MalachiTemp.Backend
{
    public class AntiReport : MonoBehaviour
    {
        private float threshold = 0.44f;
        void Update()
        {
            foreach (GorillaPlayerScoreboardLine line in GorillaScoreboardTotalUpdater.allScoreboardLines)
            {
                if (line.linePlayer == NetworkSystem.Instance.LocalPlayer)
                {
                    Transform report = line.reportButton.gameObject.transform;
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (vrrig != GorillaTagger.Instance.offlineVRRig)
                        {
                            float D1 = Vector3.Distance(vrrig.rightHandTransform.position, report.position);
                            float D2 = Vector3.Distance(vrrig.leftHandTransform.position, report.position);

                            if (D1 < threshold || D2 < threshold)
                            {
                                PhotonNetwork.Disconnect();
                                NotifiLib.SendNotification("<color=grey>[</color><color=purple>ANTI-REPORT</color><color=grey>]</color> " + " someone attempted to report you, you have been disconnected.");
                            }
                        }
                    }
                }
            }
        }
    }
}
