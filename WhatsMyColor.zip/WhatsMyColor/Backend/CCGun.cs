﻿using BepInEx;
using GorillaNetworking;
using Photon.Pun;
using System;
using UnityEngine;
using UnityEngine.XR;

namespace MalachiTemp.Backend
{
    public class CCGun : MonoBehaviour
    {
        public static GameObject pointer;

        void Update()
        {
            bool grip = ControllerInputPoller.GetGrab(XRNode.RightHand);
            if (grip)
            {
                if (pointer != null)
                {
                    Destroy(pointer);
                    pointer = null;
                }
                return;
            }

            RaycastHit raycastHit;
            bool hasHit = Physics.Raycast(
                GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up,
                -GorillaLocomotion.Player.Instance.rightControllerTransform.up,
                out raycastHit
            );

            if (hasHit && pointer == null)
            {
                pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Destroy(pointer.GetComponent<Rigidbody>());
                Destroy(pointer.GetComponent<SphereCollider>());
                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                pointer.GetComponent<Renderer>().material.color = Color.white;
            }

            if (pointer != null)
            {
                pointer.transform.position = raycastHit.point;

                float triggerValue = ControllerInputPoller.TriggerFloat(XRNode.RightHand);
                if (triggerValue > 0.5f)
                {
                    VRRig closestRig = FindClosestVRRig(pointer.transform.position);
                    if (closestRig != null)
                    {
                        pointer.GetComponent<Renderer>().material.color = closestRig.playerColor;
                        ChangeColor(closestRig.playerColor);
                        ChangeName(closestRig.playerNameVisible);
                    }
                }
                else
                {
                    pointer.GetComponent<Renderer>().material.color = Color.white;
                }
            }
        }
        public static void ChangeName(string PlayerName)
        {
            try
            {
                GorillaComputer.instance.currentName = PlayerName;
                PhotonNetwork.LocalPlayer.NickName = PlayerName;
                GorillaComputer.instance.offlineVRRigNametagText.text = PlayerName;
                GorillaComputer.instance.savedName = PlayerName;
                PlayerPrefs.SetString("playerName", PlayerName);
                PlayerPrefs.Save();
            }
            catch (Exception exception)
            {
            }
        }


        public static void ChangeColor(Color color)
        {
            PlayerPrefs.SetFloat("redValue", Mathf.Clamp(color.r, 0f, 1f));
            PlayerPrefs.SetFloat("greenValue", Mathf.Clamp(color.g, 0f, 1f));
            PlayerPrefs.SetFloat("blueValue", Mathf.Clamp(color.b, 0f, 1f));

            GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
            PlayerPrefs.Save();
        }

        private VRRig FindClosestVRRig(Vector3 position)
        {
            VRRig[] rigs = FindObjectsOfType<VRRig>();
            VRRig closestRig = null;
            float closestDistance = Mathf.Infinity;

            foreach (var rig in rigs)
            {
                float distance = Vector3.Distance(position, rig.transform.position);
                if (distance < 1f && distance < closestDistance) // 1f as the threshold
                {
                    closestDistance = distance;
                    closestRig = rig;
                }
            }

            return closestRig;
        }
    }
}
